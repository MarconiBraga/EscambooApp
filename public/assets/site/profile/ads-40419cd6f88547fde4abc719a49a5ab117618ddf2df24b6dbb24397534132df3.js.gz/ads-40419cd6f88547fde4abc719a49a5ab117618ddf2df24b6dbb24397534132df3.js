$(function() {
    $('.datepicker').datepicker();
});
